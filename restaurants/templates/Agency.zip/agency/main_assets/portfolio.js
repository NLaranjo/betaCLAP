/*
var LINK_RESTAURANTS ="./tenho_fome.html";
var LINK_NOTES = "#";
var LINK_LOCATION= "#";
var LINK_AS= "#";




createGridElem("./main_assets/assets/img/portfolio/ementas400x640.png", "Ementas",LINK_RESTAURANTS);
createGridElem("./main_assets/assets/img/portfolio/servicos400x250.png", "SA",LINK_AS);
createGridElem("./main_assets/assets/img/portfolio/apontamentos400x640.png", "Apontamentos",LINK_NOTES);
createGridElem("./main_assets/assets/img/portfolio/cafe400x300.png", "Coffe shops",LINK_RESTAURANTS);
createGridElem("./main_assets/assets/img/portfolio/10.png", "Dummy","#");
createGridElem("./main_assets/assets/img/portfolio/9.jpg", "Dummy","#");
createGridElem("./main_assets/assets/img/portfolio/2.jpg", "Dummy","#");
createGridElem("./main_assets/assets/img/portfolio/14.png", "Dummy","#");
createGridElem("./main_assets/assets/img/portfolio/5.jpg", "Dummy","#");

*/







