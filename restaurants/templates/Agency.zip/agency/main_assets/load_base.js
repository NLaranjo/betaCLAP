document.write(' <link href="./main_assets/assets/css/bootstrap.css" rel="stylesheet" />');
document.write(' <link href="./main_assets/assets/css/main.css" rel="stylesheet" /> ');
document.write('<link href="./main_assets/assets/css/font-awesome.min.css" rel="stylesheet" />');
document.write('<link href="http://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic" rel="stylesheet" type="text/css" /> ');
document.write('<link href="http://fonts.googleapis.com/css?family=Raleway:400,300,700" rel="stylesheet" type="text/css" /> ');
document.write('<script src="./main_assets/assets/js/modernizr.custom.js"></script>');
document.write(' <script src="./main_assets/assets/js/modernizr.custom.js"></script>');




