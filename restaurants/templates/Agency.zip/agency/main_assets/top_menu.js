
/*
*
* WRAP MENU
*
*/
var h1=createMenuTitle("CLAPUM","#");
divwrap.appendChild(h1);


a1= createMenuOpt("Home","index.html");
divwrap.appendChild(a1);

a2= createMenuOpt("Alimentação", "tenho_fome.html");
divwrap.appendChild(a2);

a3= createMenuOpt("Apontamentos","apontamentos.html");
divwrap.appendChild(a3);

a4= createMenuOpt("Localização", "location.html");
divwrap.appendChild(a4);

var fba=createMenuButn("fa fa-facebook");
divwrap.appendChild(fba);

var twt=createMenuButn("fa fa-twitter");
divwrap.appendChild(twt);

/*
*
* PAGE TOP - CAMPUS INFO
*
*/

logo_campus=insertLogo("./main_assets/assets/img/logo_um.jpg");
col3.appendChild(logo_campus);

