document.write('<script src="./main_assets/assets/js/modernizr.custom.js"></script>');
document.write(' <script src="./main_assets/assets/js/modernizr.custom.js"></script>');

document.write(' <script src="https://code.jquery.com/jquery-1.10.2.min.js"></script>');

document.write(' <script src="./main_assets/assets/js/bootstrap.min.js"></script>');

        
document.write('<script src="./main_assets/assets/js/main.js"></script>');
       document.write('<script src="./main_assets/assets/js/masonry.pkgd.min.js"></script>');
        document.write('<script src="./main_assets/assets/js/imagesloaded.js"></script>');
        document.write('<script src="./main_assets/assets/js/classie.js"></script>');
        document.write('<script src="./main_assets/assets/js/AnimOnScroll.js"></script>');



