document.write('<script src="./main_assets/assets_helios/js/jquery.min.js"></script>');
document.write('<script src="./main_assets/assets_helios/js/jquery.dropotron.min.js"></script>');
document.write('<script src="./main_assets/assets_helios/js/jquery.scrolly.min.js"></script>');
document.write('<script src="./main_assets/assets_helios/js/jquery.onvisible.min.js"></script>');
document.write('<script src="./main_assets/assets_helios/js/skel.min.js"></script>');
document.write('<script src="./main_assets/assets_helios/js/init.js"></script>');
  