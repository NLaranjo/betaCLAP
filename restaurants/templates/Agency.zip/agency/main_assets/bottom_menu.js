menu1=createBottomMenu("col-lg-3 dg","1","RESTAURANTES","Vê as tuas opções","fa fa-user");
row_sf.appendChild(menu1);
menu2=createBottomMenu("col-lg-3 dg","2","APONTAMENTOS","Vê as tuas opções","fa fa-copy");
row_sf.appendChild(menu2);
menu3=createBottomMenu("col-lg-3 dg","3","SERVIÇOS","Vê as tuas opções","fa fa-cogs");
row_sf.appendChild(menu3);
menu4=createBottomMenu("col-lg-3 dg","4","LOCALIZAÇÃO","Vê as tuas opções","fa fa-map-marker");
row_sf.appendChild(menu4);